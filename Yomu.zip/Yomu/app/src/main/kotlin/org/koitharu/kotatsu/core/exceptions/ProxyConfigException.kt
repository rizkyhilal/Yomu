package org.koitharu.kotatsu.core.exceptions

import java.net.ProtocolException

class ProxyConfigException : ProtocolException("Wrong proxy configuration")
