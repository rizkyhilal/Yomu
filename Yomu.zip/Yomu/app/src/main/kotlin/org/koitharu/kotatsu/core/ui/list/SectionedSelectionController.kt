package org.koitharu.kotatsu.core.ui.list

private const val PROVIDER_NAME = "selection_decoration_sectioned"

