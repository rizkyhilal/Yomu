package org.koitharu.kotatsu.core.ui.list

interface OnTipCloseListener<T> {

	fun onCloseTip(tip: T)
}
