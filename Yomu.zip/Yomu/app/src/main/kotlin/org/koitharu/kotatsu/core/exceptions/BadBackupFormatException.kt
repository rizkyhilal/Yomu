package org.koitharu.kotatsu.core.exceptions

import java.io.IOException

class BadBackupFormatException(cause: Throwable?) : IOException(cause)
