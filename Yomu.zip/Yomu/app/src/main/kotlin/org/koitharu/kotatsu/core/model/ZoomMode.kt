package org.koitharu.kotatsu.core.model

enum class ZoomMode {

	FIT_CENTER, FIT_HEIGHT, FIT_WIDTH, KEEP_START
}