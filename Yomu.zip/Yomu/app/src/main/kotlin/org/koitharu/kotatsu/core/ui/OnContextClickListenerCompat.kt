package org.koitharu.kotatsu.core.ui

import android.view.View

fun interface OnContextClickListenerCompat {

	fun onContextClick(v: View): Boolean
}
