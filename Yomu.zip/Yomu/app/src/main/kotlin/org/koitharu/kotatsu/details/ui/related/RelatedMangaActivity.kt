package org.koitharu.kotatsu.details.ui.related

import org.koitharu.kotatsu.core.ui.FragmentContainerActivity

class RelatedMangaActivity : FragmentContainerActivity(RelatedListFragment::class.java)
