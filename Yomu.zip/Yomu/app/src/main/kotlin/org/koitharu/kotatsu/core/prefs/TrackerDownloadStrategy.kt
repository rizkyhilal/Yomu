package org.koitharu.kotatsu.core.prefs

import androidx.annotation.Keep

@Keep
enum class TrackerDownloadStrategy {

	DISABLED, DOWNLOADED;
}
