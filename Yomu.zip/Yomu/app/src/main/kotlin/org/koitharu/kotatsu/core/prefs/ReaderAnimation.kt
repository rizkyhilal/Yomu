package org.koitharu.kotatsu.core.prefs

import androidx.annotation.Keep

@Keep
enum class ReaderAnimation {

	// Do not rename this
	NONE, DEFAULT, ADVANCED;
}
