package org.koitharu.kotatsu.core.prefs

import androidx.annotation.Keep

@Keep
enum class DownloadFormat {

	AUTOMATIC,
	SINGLE_CBZ,
	MULTIPLE_CBZ,
}
