package org.koitharu.kotatsu.bookmarks.ui

import org.koitharu.kotatsu.core.ui.FragmentContainerActivity

class AllBookmarksActivity : FragmentContainerActivity(AllBookmarksFragment::class.java)
